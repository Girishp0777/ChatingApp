const jwt=require('jsonwebtoken')

const refreshtoken = async(req, res, next)=>{
    const cookie = req.headers.cookie;
    const token = cookie?.split("=")[1];

    if(!token){
        return res.status(400).json({message:"Token Not Found"});
    }

    jwt.verify(String(token),process.env.JWT_SECRET_KEY,(Error, newUser)=>{
        if(Error){
            return res.status(400).json({message:"Invalid Token"});
        }

        res.clearCookie(`${newUser.id}`);
        req.cookies[`${newUser.id}`]="";

        const retoken = jwt.sign({id:newUser.id},process.env.JWT_SECRET_KEY,{expiresIn:"5m"});
        console.log("Refresh Token:\n",retoken);

        res.cookie(String(newUser.id),retoken,{
            path:"/",
            expiresIn: new Date(Date.now()+1000*9600),
            httponly:true,
            sameSite:"lax"
        });

        req.newUser=newUser.id;
        next();
    })
};

module.exports=refreshtoken;